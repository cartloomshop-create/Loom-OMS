# 🛒 CartLoom OMS — Full-Stack Order Management System

A complete Order Management System for CartLoom, a D2C earrings brand.
Built with React.js + Tailwind CSS (frontend) and Node.js + Express + MongoDB (backend).

---

## 📁 Folder Structure

```
cartloom/
├── backend/
│   ├── models/
│   │   ├── User.js          # User auth model
│   │   └── Order.js         # Order model with full schema
│   ├── routes/
│   │   ├── auth.js          # Login/register endpoints
│   │   ├── orders.js        # Full CRUD + CSV import/export
│   │   ├── invoices.js      # PDF invoice generation
│   │   ├── analytics.js     # Dashboard + revenue stats
│   │   └── packing.js       # Packing queue + slip PDF
│   ├── middleware/
│   │   └── auth.js          # JWT protect middleware
│   ├── server.js            # Express app entry point
│   ├── seed.js              # Sample data seeder
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── layout/
    │   │   │   └── Layout.jsx       # Sidebar + header shell
    │   │   └── orders/
    │   │       ├── OrderModal.jsx   # Create/edit order form
    │   │       ├── ShipModal.jsx    # Add tracking modal
    │   │       └── CSVImportModal.jsx
    │   ├── context/
    │   │   └── AuthContext.jsx
    │   ├── pages/
    │   │   ├── Login.jsx
    │   │   ├── Dashboard.jsx        # Stats + charts
    │   │   ├── Orders.jsx           # Order list + filters
    │   │   ├── OrderDetail.jsx      # Single order + QR
    │   │   ├── Packing.jsx          # Packing queue
    │   │   ├── Invoices.jsx         # Invoice generator
    │   │   └── Analytics.jsx        # Revenue charts
    │   ├── utils/
    │   │   └── api.js               # Axios instance
    │   ├── App.jsx                  # Routes
    │   ├── index.js
    │   └── index.css                # Tailwind + custom styles
    ├── tailwind.config.js
    ├── vercel.json
    └── package.json
```

---

## 🚀 Quick Start (Local Dev)

### Prerequisites
- Node.js 18+
- MongoDB (local) OR MongoDB Atlas URI

### 1. Backend Setup

```bash
cd cartloom/backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm run dev
```

### 2. Seed Sample Data

```bash
cd cartloom/backend
node seed.js
```

This creates:
- Admin user: `admin@cartloom.in` / `cartloom123`
- 40 sample orders across Meesho + Website channels

### 3. Frontend Setup

```bash
cd cartloom/frontend
npm install
npm start
```

Visit `http://localhost:3000` and login with the seeded credentials.

---

## 🌐 Deployment Guide

### Step 1: MongoDB Atlas (Free)

1. Go to [cloud.mongodb.com](https://cloud.mongodb.com)
2. Create a free M0 cluster
3. Create a database user (save credentials)
4. Whitelist IP: `0.0.0.0/0` (all IPs)
5. Copy the connection string:
   ```
   mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/cartloom
   ```

### Step 2: Deploy Backend on Render (Free)

1. Push your code to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Settings:
   - **Root Directory**: `backend`
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
5. Add Environment Variables:
   ```
   MONGODB_URI=<your atlas URI>
   JWT_SECRET=<strong random string>
   JWT_EXPIRES_IN=7d
   FRONTEND_URL=https://your-app.vercel.app
   PORT=5000
   ```
6. Deploy. Note your backend URL: `https://cartloom-api.onrender.com`

### Step 3: Deploy Frontend on Vercel (Free)

1. Go to [vercel.com](https://vercel.com) → New Project
2. Import your GitHub repo
3. Settings:
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `build`
4. Add Environment Variable:
   ```
   REACT_APP_API_URL=https://cartloom-api.onrender.com
   ```
5. Edit `vercel.json` — replace the destination URL with your Render URL
6. Deploy!

---

## 📡 API Routes Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new admin |
| POST | `/api/auth/login` | Login → returns JWT |
| GET | `/api/auth/me` | Get current user |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/orders` | List all (with filters: status, source, search, page) |
| POST | `/api/orders` | Create order |
| GET | `/api/orders/:id` | Get single order |
| PUT | `/api/orders/:id` | Update order |
| DELETE | `/api/orders/:id` | Delete order |
| PATCH | `/api/orders/:id/pack` | Mark as packed |
| PATCH | `/api/orders/:id/ship` | Mark as shipped (+ tracking) |
| PATCH | `/api/orders/:id/deliver` | Mark as delivered |
| POST | `/api/orders/bulk/status` | Bulk status update |
| POST | `/api/orders/import/csv` | Import CSV file |
| GET | `/api/orders/export/csv` | Export to CSV |

### Invoices
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/invoices` | List all invoiced orders |
| GET | `/api/invoices/:orderId/pdf` | Generate & download PDF |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/analytics/dashboard` | Full dashboard stats |
| GET | `/api/analytics/revenue?period=30` | Revenue over time |

### Packing
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/packing/queue` | New orders to pack |
| POST | `/api/packing/slip/pdf` | Generate packing slips PDF |

---

## 📄 Meesho CSV Format

CartLoom accepts Meesho exports with these column names (case-insensitive):

```csv
Customer Name,Phone,Address,City,State,Pincode,Product,Quantity,Price,Order ID
Priya Sharma,9876543210,"123 Main Street",Mumbai,Maharashtra,400001,Kundan Jhumki,1,299,MSH-001
```

---

## ✨ Features Summary

| Feature | Status |
|---------|--------|
| JWT Authentication | ✅ |
| Multi-channel orders (Meesho, Website) | ✅ |
| CSV Import (Meesho format) | ✅ |
| CSV Export | ✅ |
| GST-ready Invoice PDF | ✅ |
| QR Code per order | ✅ |
| Packing queue + bulk pack | ✅ |
| Packing slip PDF | ✅ |
| Courier tracking | ✅ |
| Dashboard analytics | ✅ |
| Revenue charts (Recharts) | ✅ |
| Channel performance | ✅ |
| WhatsApp trigger (mock link) | ✅ |
| Mobile responsive | ✅ |
| Dark sidebar (Shopify-like) | ✅ |

---

## 🔧 Customization Tips

### Add your GSTIN
In `backend/routes/invoices.js`, line ~35:
```js
doc.text('GSTIN: 29XXXXX1234X1ZX', ...);
// Replace with your actual GSTIN
```

### Add WhatsApp Business API
Replace the WhatsApp link in `OrderDetail.jsx` with your WABA API call.

### Add Shiprocket Integration
In `backend/routes/orders.js`, on ship action, call Shiprocket's API:
```js
// POST https://apiv2.shiprocket.in/v1/external/orders/create/adhoc
```

### Environment Variables Summary
```env
# Backend (.env)
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your_super_secret_key
JWT_EXPIRES_IN=7d
FRONTEND_URL=https://your-frontend.vercel.app
PORT=5000

# Frontend (.env)
REACT_APP_API_URL=https://your-backend.onrender.com
```

---

Made with ❤️ for CartLoom | D2C Earrings Brand
