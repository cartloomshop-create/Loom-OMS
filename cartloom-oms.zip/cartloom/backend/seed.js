const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const Order = require('./models/Order');
const User = require('./models/User');

const earrings = [
  'Kundan Jhumki Earrings', 'Pearl Drop Earrings', 'Oxidised Silver Chandbali',
  'Gold Plated Hoop Earrings', 'Terracotta Stud Earrings', 'Beaded Tassel Earrings',
  'Mirror Work Jhumka', 'Thread Work Earrings', 'Meenakari Earrings', 'Boho Cuff Earrings'
];

const customers = [
  { name: 'Priya Sharma', phone: '9876543210', city: 'Mumbai', state: 'Maharashtra', pincode: '400001' },
  { name: 'Anita Verma', phone: '8765432109', city: 'Delhi', state: 'Delhi', pincode: '110001' },
  { name: 'Sunita Reddy', phone: '7654321098', city: 'Hyderabad', state: 'Telangana', pincode: '500001' },
  { name: 'Kavya Nair', phone: '9543210987', city: 'Kochi', state: 'Kerala', pincode: '682001' },
  { name: 'Meena Iyer', phone: '9432109876', city: 'Chennai', state: 'Tamil Nadu', pincode: '600001' },
  { name: 'Ritu Singh', phone: '8321098765', city: 'Jaipur', state: 'Rajasthan', pincode: '302001' },
  { name: 'Deepika Patel', phone: '7210987654', city: 'Ahmedabad', state: 'Gujarat', pincode: '380001' },
  { name: 'Swati Gupta', phone: '9109876543', city: 'Lucknow', state: 'Uttar Pradesh', pincode: '226001' },
];

const statuses = ['new', 'new', 'new', 'packed', 'packed', 'shipped', 'shipped', 'delivered'];
const sources = ['meesho', 'meesho', 'meesho', 'website', 'website'];

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/cartloom');
  console.log('Connected to MongoDB');

  // Create admin user
  await User.deleteMany({});
  const admin = await User.create({
    name: 'CartLoom Admin',
    email: 'admin@cartloom.in',
    password: 'cartloom123',
    role: 'admin'
  });
  console.log('✅ Admin user: admin@cartloom.in / cartloom123');

  // Create sample orders
  await Order.deleteMany({});
  const orders = [];
  for (let i = 0; i < 40; i++) {
    const customer = customers[i % customers.length];
    const product = earrings[i % earrings.length];
    const price = [149, 199, 249, 299, 349, 399, 449][i % 7];
    const qty = [1, 1, 1, 2, 1][i % 5];
    const status = statuses[i % statuses.length];
    const source = sources[i % sources.length];

    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 30));

    const orderData = {
      customer: {
        name: customer.name,
        phone: customer.phone,
        address: { line1: `${i + 1} Main Street`, city: customer.city, state: customer.state, pincode: customer.pincode }
      },
      products: [{ name: product, quantity: qty, price, hsn: '7117', gstRate: 3 }],
      totalAmount: price * qty,
      status,
      source,
      createdBy: admin._id,
      createdAt: date
    };

    if (status === 'shipped' || status === 'delivered') {
      orderData.courier = { name: 'Delhivery', trackingId: `DLVRY${100000 + i}`, shippedAt: date };
    }

    orders.push(orderData);
  }

  for (const o of orders) {
    await Order.create(o);
  }
  console.log(`✅ Created ${orders.length} sample orders`);
  console.log('\n🚀 Seed complete! Login at http://localhost:3000');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
