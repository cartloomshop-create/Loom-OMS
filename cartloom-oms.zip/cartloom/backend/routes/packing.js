const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

// Get packing queue (new orders)
router.get('/queue', protect, async (req, res) => {
  try {
    const orders = await Order.find({ status: 'new' }).sort({ createdAt: 1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Generate packing slip PDF for multiple orders
router.post('/slip/pdf', protect, async (req, res) => {
  try {
    const { orderIds } = req.body;
    const orders = await Order.find({ _id: { $in: orderIds } });

    const doc = new PDFDocument({ margin: 40, size: 'A4' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="packing-slip-${Date.now()}.pdf"`);
    doc.pipe(res);

    orders.forEach((order, idx) => {
      if (idx > 0) doc.addPage();

      // Header
      doc.rect(0, 0, 595, 80).fill('#1a1a2e');
      doc.fillColor('#ffffff').fontSize(20).font('Helvetica-Bold').text('CartLoom', 40, 20);
      doc.fillColor('#C8522A').fontSize(10).font('Helvetica').text('PACKING SLIP', 40, 46);
      doc.fillColor('#ffffff').fontSize(10).text(`Order: ${order.orderId}`, 400, 20, { align: 'right', width: 155 });
      doc.fillColor('#aaaaaa').fontSize(9).text(`Date: ${new Date().toLocaleDateString('en-IN')}`, 400, 36, { align: 'right', width: 155 });

      // Customer
      doc.fillColor('#1a1a2e').fontSize(11).font('Helvetica-Bold').text('SHIP TO:', 40, 100);
      doc.fontSize(13).text(order.customer.name, 40, 116);
      doc.font('Helvetica').fontSize(9).fillColor('#555555');
      if (order.customer.phone) doc.text(`Phone: ${order.customer.phone}`, 40, 133);
      const addr = order.customer.address;
      if (addr?.line1) doc.text(addr.line1, 40, 145);
      const cityLine = [addr?.city, addr?.state, addr?.pincode].filter(Boolean).join(', ');
      if (cityLine) doc.text(cityLine, 40, 157);

      // Source badge
      doc.rect(400, 100, 80, 20).fill(order.source === 'meesho' ? '#f97316' : '#3b82f6');
      doc.fillColor('#ffffff').fontSize(9).font('Helvetica-Bold').text(order.source.toUpperCase(), 400, 107, { align: 'center', width: 80 });

      // Products
      doc.moveTo(40, 180).lineTo(555, 180).strokeColor('#e5e7eb').stroke();
      doc.fillColor('#1a1a2e').fontSize(10).font('Helvetica-Bold').text('ITEMS TO PACK:', 40, 190);

      let y = 210;
      order.products.forEach((p, i) => {
        doc.rect(40, y - 5, 515, 22).fill(i % 2 === 0 ? '#f8f9fa' : '#ffffff');
        doc.fillColor('#333333').font('Helvetica').fontSize(10);
        doc.text(`${i + 1}. ${p.name}`, 50, y);
        doc.text(`Qty: ${p.quantity}`, 450, y);
        y += 25;
      });

      // Box at bottom for packer signature
      doc.rect(40, 680, 240, 60).stroke('#cccccc');
      doc.fillColor('#888888').fontSize(8).text('PACKED BY:', 50, 688);
      doc.text('Date:', 50, 710);
      doc.rect(300, 680, 255, 60).stroke('#cccccc');
      doc.text('VERIFIED BY:', 310, 688);
      doc.text(`Slip #: ${order.packingSlip?.slipNumber || 'N/A'}`, 310, 710);
    });

    doc.end();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
