const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

router.get('/dashboard', protect, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);

    const last30 = new Date(); last30.setDate(last30.getDate() - 30);
    const last7 = new Date(); last7.setDate(last7.getDate() - 7);

    const [
      totalOrders, todayOrders, newOrders, packedOrders,
      shippedOrders, deliveredOrders, totalRevenue30, channelStats,
      last7Days, recentOrders
    ] = await Promise.all([
      Order.countDocuments({}),
      Order.countDocuments({ createdAt: { $gte: today, $lt: tomorrow } }),
      Order.countDocuments({ status: 'new' }),
      Order.countDocuments({ status: 'packed' }),
      Order.countDocuments({ status: 'shipped' }),
      Order.countDocuments({ status: 'delivered' }),
      Order.aggregate([
        { $match: { createdAt: { $gte: last30 }, status: { $ne: 'cancelled' } } },
        { $group: { _id: null, revenue: { $sum: '$totalAmount' }, orders: { $sum: 1 } } }
      ]),
      Order.aggregate([
        { $group: { _id: '$source', count: { $sum: 1 }, revenue: { $sum: '$totalAmount' } } }
      ]),
      Order.aggregate([
        { $match: { createdAt: { $gte: last7 } } },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
            orders: { $sum: 1 },
            revenue: { $sum: '$totalAmount' }
          }
        },
        { $sort: { _id: 1 } }
      ]),
      Order.find({}).sort({ createdAt: -1 }).limit(5)
    ]);

    res.json({
      summary: {
        totalOrders, todayOrders, newOrders, packedOrders,
        shippedOrders, deliveredOrders,
        revenue30Days: totalRevenue30[0]?.revenue || 0,
        orders30Days: totalRevenue30[0]?.orders || 0
      },
      channelStats,
      last7Days,
      recentOrders
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/revenue', protect, async (req, res) => {
  try {
    const { period = '30' } = req.query;
    const days = parseInt(period);
    const since = new Date(); since.setDate(since.getDate() - days);

    const data = await Order.aggregate([
      { $match: { createdAt: { $gte: since }, status: { $ne: 'cancelled' } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          orders: { $sum: 1 },
          revenue: { $sum: '$totalAmount' },
          meesho: { $sum: { $cond: [{ $eq: ['$source', 'meesho'] }, 1, 0] } },
          website: { $sum: { $cond: [{ $eq: ['$source', 'website'] }, 1, 0] } }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
