const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

const upload = multer({ dest: 'uploads/' });

// GET all orders with filters
router.get('/', protect, async (req, res) => {
  try {
    const { status, source, search, page = 1, limit = 50, startDate, endDate } = req.query;
    const query = {};
    if (status) query.status = status;
    if (source) query.source = source;
    if (search) {
      query.$or = [
        { orderId: { $regex: search, $options: 'i' } },
        { 'customer.name': { $regex: search, $options: 'i' } },
        { 'customer.phone': { $regex: search, $options: 'i' } }
      ];
    }
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate + 'T23:59:59');
    }

    const total = await Order.countDocuments(query);
    const orders = await Order.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.json({ orders, total, page: parseInt(page), totalPages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET single order
router.get('/:id', protect, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CREATE order
router.post('/', protect, async (req, res) => {
  try {
    const orderData = { ...req.body, createdBy: req.user._id };
    const order = await Order.create(orderData);
    // Generate QR Code
    const qrData = JSON.stringify({ orderId: order.orderId, customer: order.customer.name });
    const qrCode = await QRCode.toDataURL(qrData);
    order.qrCode = qrCode;
    await order.save();
    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE order
router.put('/:id', protect, async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// MARK AS PACKED
router.patch('/:id/pack', protect, async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, {
      status: 'packed',
      packedAt: new Date(),
      'packingSlip.generatedAt': new Date(),
      'packingSlip.slipNumber': `PS-${Date.now()}`
    }, { new: true });
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// MARK AS SHIPPED
router.patch('/:id/ship', protect, async (req, res) => {
  try {
    const { courierName, trackingId } = req.body;
    const order = await Order.findByIdAndUpdate(req.params.id, {
      status: 'shipped',
      'courier.name': courierName,
      'courier.trackingId': trackingId,
      'courier.shippedAt': new Date()
    }, { new: true });
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// MARK AS DELIVERED
router.patch('/:id/deliver', protect, async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, {
      status: 'delivered',
      deliveredAt: new Date()
    }, { new: true });
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// BULK UPDATE STATUS
router.post('/bulk/status', protect, async (req, res) => {
  try {
    const { orderIds, status } = req.body;
    const update = { status };
    if (status === 'packed') { update.packedAt = new Date(); update['packingSlip.generatedAt'] = new Date(); }
    if (status === 'shipped') update['courier.shippedAt'] = new Date();
    if (status === 'delivered') update.deliveredAt = new Date();
    await Order.updateMany({ _id: { $in: orderIds } }, update);
    res.json({ message: `${orderIds.length} orders updated to ${status}` });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CSV IMPORT (Meesho format)
router.post('/import/csv', protect, upload.single('file'), async (req, res) => {
  try {
    const results = [];
    const source = req.body.source || 'meesho';
    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on('data', (row) => results.push(row))
      .on('end', async () => {
        const orders = [];
        for (const row of results) {
          try {
            const orderData = {
              source,
              customer: {
                name: row['Customer Name'] || row['customer_name'] || row['Name'] || 'Unknown',
                phone: row['Phone'] || row['phone'] || row['Mobile'] || '',
                email: row['Email'] || row['email'] || '',
                address: {
                  line1: row['Address'] || row['address'] || row['Address Line 1'] || '',
                  city: row['City'] || row['city'] || '',
                  state: row['State'] || row['state'] || '',
                  pincode: row['Pincode'] || row['pincode'] || row['PIN'] || ''
                }
              },
              products: [{
                name: row['Product'] || row['product_name'] || row['Item'] || 'Earrings',
                quantity: parseInt(row['Quantity'] || row['qty'] || '1'),
                price: parseFloat(row['Price'] || row['price'] || row['Amount'] || '0'),
                sku: row['SKU'] || row['sku'] || ''
              }],
              totalAmount: parseFloat(row['Total'] || row['total_amount'] || row['Price'] || '0'),
              meeshoOrderId: row['Order ID'] || row['order_id'] || row['Meesho Order ID'] || '',
              status: 'new'
            };
            if (!orderData.customer.name || orderData.customer.name === 'Unknown') continue;
            const order = await Order.create(orderData);
            const qrData = JSON.stringify({ orderId: order.orderId, customer: order.customer.name });
            order.qrCode = await QRCode.toDataURL(qrData);
            await order.save();
            orders.push(order);
          } catch (e) { console.log('Row error:', e.message); }
        }
        fs.unlinkSync(req.file.path);
        res.json({ imported: orders.length, total: results.length, orders });
      });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// EXPORT to CSV
router.get('/export/csv', protect, async (req, res) => {
  try {
    const { status, source } = req.query;
    const query = {};
    if (status) query.status = status;
    if (source) query.source = source;
    const orders = await Order.find(query).sort({ createdAt: -1 });

    const csvRows = [
      ['Order ID', 'Customer Name', 'Phone', 'Email', 'Address', 'City', 'State', 'Pincode', 'Product', 'Qty', 'Price', 'Total', 'Status', 'Source', 'Tracking ID', 'Date'].join(',')
    ];

    orders.forEach(o => {
      const productName = o.products.map(p => p.name).join('; ');
      const qty = o.products.reduce((s, p) => s + p.quantity, 0);
      const addr = `"${o.customer.address?.line1 || ''}"`;
      csvRows.push([
        o.orderId, `"${o.customer.name}"`, o.customer.phone || '', o.customer.email || '',
        addr, o.customer.address?.city || '', o.customer.address?.state || '',
        o.customer.address?.pincode || '', `"${productName}"`, qty, o.products[0]?.price || 0,
        o.totalAmount, o.status, o.source, o.courier?.trackingId || '',
        new Date(o.createdAt).toLocaleDateString('en-IN')
      ].join(','));
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="cartloom-orders-${Date.now()}.csv"`);
    res.send(csvRows.join('\n'));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE order
router.delete('/:id', protect, async (req, res) => {
  try {
    await Order.findByIdAndDelete(req.params.id);
    res.json({ message: 'Order deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
