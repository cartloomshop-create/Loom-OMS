const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

// Generate Invoice PDF
router.get('/:orderId/pdf', protect, async (req, res) => {
  try {
    const order = await Order.findOne({ orderId: req.params.orderId });
    if (!order) return res.status(404).json({ message: 'Order not found' });

    // Generate invoice number if not exists
    if (!order.invoiceNumber) {
      const count = await Order.countDocuments({ invoiceNumber: { $exists: true, $ne: null } });
      order.invoiceNumber = `INV-CL-${new Date().getFullYear()}-${String(count + 1).padStart(5, '0')}`;
      order.invoiceDate = new Date();
      await order.save();
    }

    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="invoice-${order.orderId}.pdf"`);
    doc.pipe(res);

    const primaryColor = '#C8522A';
    const darkColor = '#1a1a2e';
    const grayColor = '#6b7280';
    const lightGray = '#f8f9fa';

    // Header background
    doc.rect(0, 0, 595, 140).fill(darkColor);

    // Brand name
    doc.fillColor('#ffffff').fontSize(28).font('Helvetica-Bold').text('CartLoom', 50, 30);
    doc.fillColor(primaryColor).fontSize(10).font('Helvetica').text('JEWELLERY & ACCESSORIES', 50, 62);
    doc.fillColor('#aaaaaa').fontSize(9).text('GSTIN: 29XXXXX1234X1ZX (update yours)', 50, 78);
    doc.text('cartloom.in | support@cartloom.in | +91 XXXXXXXXXX', 50, 92);

    // Invoice title on right
    doc.fillColor('#ffffff').fontSize(22).font('Helvetica-Bold').text('INVOICE', 380, 30, { align: 'right', width: 165 });
    doc.fillColor('#aaaaaa').fontSize(10).font('Helvetica').text(`# ${order.invoiceNumber}`, 380, 58, { align: 'right', width: 165 });
    doc.fillColor('#dddddd').fontSize(9).text(`Date: ${new Date(order.invoiceDate).toLocaleDateString('en-IN')}`, 380, 76, { align: 'right', width: 165 });
    doc.text(`Order: ${order.orderId}`, 380, 92, { align: 'right', width: 165 });

    // Bill To section
    doc.fillColor(darkColor).fontSize(10).font('Helvetica-Bold').text('BILL TO:', 50, 160);
    doc.fillColor('#333333').fontSize(12).font('Helvetica-Bold').text(order.customer.name, 50, 175);
    doc.font('Helvetica').fontSize(9).fillColor(grayColor);
    if (order.customer.phone) doc.text(`Phone: ${order.customer.phone}`, 50, 190);
    if (order.customer.email) doc.text(`Email: ${order.customer.email}`, 50, 202);
    const addr = order.customer.address;
    if (addr?.line1) doc.text(addr.line1, 50, 214);
    const cityLine = [addr?.city, addr?.state, addr?.pincode].filter(Boolean).join(', ');
    if (cityLine) doc.text(cityLine, 50, 226);

    // Order details on right
    doc.fillColor(darkColor).fontSize(10).font('Helvetica-Bold').text('ORDER INFO:', 360, 160);
    doc.font('Helvetica').fontSize(9).fillColor(grayColor);
    doc.text(`Source: ${order.source.charAt(0).toUpperCase() + order.source.slice(1)}`, 360, 175);
    doc.text(`Status: ${order.status.toUpperCase()}`, 360, 187);
    if (order.courier?.trackingId) doc.text(`Tracking: ${order.courier.trackingId}`, 360, 199);
    if (order.courier?.name) doc.text(`Courier: ${order.courier.name}`, 360, 211);

    // Divider
    doc.moveTo(50, 255).lineTo(545, 255).strokeColor('#e5e7eb').stroke();

    // Products table header
    const tableTop = 270;
    doc.rect(50, tableTop, 495, 25).fill(darkColor);
    doc.fillColor('#ffffff').fontSize(9).font('Helvetica-Bold');
    doc.text('#', 60, tableTop + 8);
    doc.text('PRODUCT', 80, tableTop + 8);
    doc.text('HSN', 300, tableTop + 8);
    doc.text('QTY', 360, tableTop + 8);
    doc.text('RATE', 400, tableTop + 8);
    doc.text('GST%', 440, tableTop + 8);
    doc.text('AMOUNT', 480, tableTop + 8);

    // Products rows
    let y = tableTop + 30;
    let subtotal = 0;
    let totalGST = 0;
    order.products.forEach((product, i) => {
      const amount = product.price * product.quantity;
      const gstAmt = (amount * (product.gstRate || 3)) / 100;
      subtotal += amount;
      totalGST += gstAmt;

      if (i % 2 === 0) doc.rect(50, y - 5, 495, 22).fill(lightGray);
      doc.fillColor(darkColor).font('Helvetica').fontSize(9);
      doc.text(String(i + 1), 60, y);
      doc.text(product.name.substring(0, 35), 80, y);
      doc.text(product.hsn || '7117', 300, y);
      doc.text(String(product.quantity), 360, y);
      doc.text(`₹${product.price.toFixed(2)}`, 400, y);
      doc.text(`${product.gstRate || 3}%`, 440, y);
      doc.text(`₹${amount.toFixed(2)}`, 480, y);
      y += 25;
    });

    // Totals
    y += 10;
    doc.moveTo(50, y).lineTo(545, y).strokeColor('#e5e7eb').stroke();
    y += 15;

    const totalsX = 380;
    doc.fillColor(grayColor).fontSize(9).font('Helvetica');
    doc.text('Subtotal:', totalsX, y); doc.text(`₹${subtotal.toFixed(2)}`, 490, y, { align: 'right', width: 55 }); y += 15;
    if (order.shippingCharge > 0) {
      doc.text('Shipping:', totalsX, y); doc.text(`₹${order.shippingCharge.toFixed(2)}`, 490, y, { align: 'right', width: 55 }); y += 15;
    }
    if (order.discountAmount > 0) {
      doc.fillColor('#16a34a').text('Discount:', totalsX, y); doc.text(`-₹${order.discountAmount.toFixed(2)}`, 490, y, { align: 'right', width: 55 }); doc.fillColor(grayColor); y += 15;
    }
    doc.text(`GST (incl.):`, totalsX, y); doc.text(`₹${totalGST.toFixed(2)}`, 490, y, { align: 'right', width: 55 }); y += 15;

    // Total box
    doc.rect(totalsX - 10, y, 175, 30).fill(darkColor);
    doc.fillColor('#ffffff').fontSize(12).font('Helvetica-Bold');
    doc.text('TOTAL:', totalsX, y + 9);
    doc.text(`₹${order.totalAmount.toFixed(2)}`, 490, y + 9, { align: 'right', width: 55 });

    // Footer
    doc.rect(0, 760, 595, 82).fill(lightGray);
    doc.fillColor(grayColor).fontSize(8).font('Helvetica');
    doc.text('Thank you for shopping with CartLoom! 💛', 50, 770, { align: 'center', width: 495 });
    doc.text('This is a computer-generated invoice. For queries: support@cartloom.in', 50, 783, { align: 'center', width: 495 });
    doc.fillColor(primaryColor).text('cartloom.in', 50, 798, { align: 'center', width: 495 });

    doc.end();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get all invoiced orders
router.get('/', protect, async (req, res) => {
  try {
    const orders = await Order.find({ invoiceNumber: { $exists: true, $ne: null } }).sort({ invoiceDate: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
