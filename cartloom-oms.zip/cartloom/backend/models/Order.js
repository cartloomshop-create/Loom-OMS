const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  sku: { type: String },
  quantity: { type: Number, required: true, default: 1 },
  price: { type: Number, required: true },
  hsn: { type: String, default: '7117' }, // HSN for imitation jewellery
  gstRate: { type: Number, default: 3 }   // 3% GST for jewellery
});

const orderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true,
    required: true
  },
  customer: {
    name: { type: String, required: true },
    phone: { type: String },
    email: { type: String },
    address: {
      line1: { type: String },
      line2: { type: String },
      city: { type: String },
      state: { type: String },
      pincode: { type: String }
    }
  },
  products: [productSchema],
  totalAmount: { type: Number, required: true },
  gstAmount: { type: Number, default: 0 },
  discountAmount: { type: Number, default: 0 },
  shippingCharge: { type: Number, default: 0 },
  status: {
    type: String,
    enum: ['new', 'packed', 'shipped', 'delivered', 'cancelled', 'returned'],
    default: 'new'
  },
  source: {
    type: String,
    enum: ['meesho', 'website', 'manual', 'instagram', 'other'],
    default: 'manual'
  },
  courier: {
    name: { type: String },
    trackingId: { type: String },
    shippedAt: { type: Date }
  },
  packingSlip: {
    generatedAt: { type: Date },
    slipNumber: { type: String }
  },
  invoiceNumber: { type: String },
  invoiceDate: { type: Date },
  qrCode: { type: String },
  barcode: { type: String },
  notes: { type: String },
  meeshoOrderId: { type: String },
  packedAt: { type: Date },
  deliveredAt: { type: Date },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

// Auto-generate orderId
orderSchema.pre('validate', async function(next) {
  if (!this.orderId) {
    const count = await mongoose.model('Order').countDocuments();
    const date = new Date();
    const yy = String(date.getFullYear()).slice(-2);
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    this.orderId = `CL-${yy}${mm}-${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
