import React, { useState, useEffect, useCallback } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';
import OrderModal from '../components/orders/OrderModal';
import ShipModal from '../components/orders/ShipModal';
import CSVImportModal from '../components/orders/CSVImportModal';

const STATUSES = ['', 'new', 'packed', 'shipped', 'delivered', 'cancelled'];
const SOURCES = ['', 'meesho', 'website', 'manual', 'instagram'];

const StatusBadge = ({ status }) => (
  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold status-${status}`}>
    {status?.charAt(0).toUpperCase() + status?.slice(1)}
  </span>
);
const SourceBadge = ({ source }) => (
  <span className={`px-2 py-0.5 rounded-full text-xs font-medium source-${source}`}>
    {source?.charAt(0).toUpperCase() + source?.slice(1)}
  </span>
);

export default function Orders() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [orders, setOrders] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editOrder, setEditOrder] = useState(null);
  const [shipOrder, setShipOrder] = useState(null);
  const [showImport, setShowImport] = useState(false);

  const status = searchParams.get('status') || '';
  const source = searchParams.get('source') || '';
  const search = searchParams.get('search') || '';
  const page = parseInt(searchParams.get('page') || '1');

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 25 };
      if (status) params.status = status;
      if (source) params.source = source;
      if (search) params.search = search;
      const { data } = await api.get('/orders', { params });
      setOrders(data.orders);
      setTotal(data.total);
    } catch { toast.error('Failed to load orders'); }
    finally { setLoading(false); }
  }, [status, source, search, page]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  const updateParam = (key, val) => {
    const p = new URLSearchParams(searchParams);
    if (val) p.set(key, val); else p.delete(key);
    p.delete('page');
    setSearchParams(p);
  };

  const handlePack = async (id) => {
    try {
      await api.patch(`/orders/${id}/pack`);
      toast.success('Order marked as packed');
      fetchOrders();
    } catch { toast.error('Failed to update'); }
  };

  const handleDeliver = async (id) => {
    try {
      await api.patch(`/orders/${id}/deliver`);
      toast.success('Order marked as delivered');
      fetchOrders();
    } catch { toast.error('Failed to update'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this order?')) return;
    try {
      await api.delete(`/orders/${id}`);
      toast.success('Order deleted');
      fetchOrders();
    } catch { toast.error('Failed to delete'); }
  };

  const handleBulkPack = async () => {
    if (!selected.length) return;
    try {
      await api.post('/orders/bulk/status', { orderIds: selected, status: 'packed' });
      toast.success(`${selected.length} orders marked as packed`);
      setSelected([]);
      fetchOrders();
    } catch { toast.error('Bulk update failed'); }
  };

  const handleExport = async () => {
    try {
      const params = new URLSearchParams();
      if (status) params.set('status', status);
      if (source) params.set('source', source);
      const token = localStorage.getItem('cl_token');
      const res = await fetch(`/api/orders/export/csv?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = 'cartloom-orders.csv'; a.click();
      URL.revokeObjectURL(url);
      toast.success('CSV exported!');
    } catch { toast.error('Export failed'); }
  };

  const toggleSelect = (id) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const toggleAll = () => setSelected(selected.length === orders.length ? [] : orders.map(o => o._id));

  const totalPages = Math.ceil(total / 25);

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Orders</h2>
          <p className="text-sm text-gray-500">{total} total orders</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setShowImport(true)} className="btn-secondary">
            📥 Import CSV
          </button>
          <button onClick={handleExport} className="btn-secondary">
            📤 Export CSV
          </button>
          <button onClick={() => { setEditOrder(null); setShowModal(true); }} className="btn-primary">
            + New Order
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="cl-card p-4 flex flex-wrap gap-3 items-center">
        <input
          type="text" placeholder="Search by name, phone, order ID..."
          value={search} onChange={e => updateParam('search', e.target.value)}
          className="flex-1 min-w-48 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400"
        />
        <select value={status} onChange={e => updateParam('status', e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
          <option value="">All Status</option>
          {STATUSES.filter(Boolean).map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>
        <select value={source} onChange={e => updateParam('source', e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
          <option value="">All Channels</option>
          {SOURCES.filter(Boolean).map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>

        {/* Status quick tabs */}
        <div className="flex gap-1 ml-auto flex-wrap">
          {['', 'new', 'packed', 'shipped', 'delivered'].map(s => (
            <button key={s} onClick={() => updateParam('status', s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${status === s ? 'bg-dark-800 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
              {s ? s.charAt(0).toUpperCase() + s.slice(1) : 'All'}
            </button>
          ))}
        </div>
      </div>

      {/* Bulk actions bar */}
      {selected.length > 0 && (
        <div className="bg-brand-50 border border-brand-200 rounded-lg px-4 py-2.5 flex items-center gap-3 text-sm flex-wrap">
          <span className="text-brand-700 font-medium">{selected.length} orders selected</span>
          <button onClick={handleBulkPack} className="btn-primary py-1.5 text-xs">📦 Mark Packed</button>
          <button onClick={() => setSelected([])} className="btn-ghost py-1.5 text-xs">Clear</button>
        </div>
      )}

      {/* Table */}
      <div className="cl-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin w-7 h-7 border-4 border-brand-600 border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="cl-table">
              <thead>
                <tr>
                  <th className="w-10">
                    <input type="checkbox" checked={selected.length === orders.length && orders.length > 0}
                      onChange={toggleAll} className="rounded" />
                  </th>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Product</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Source</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order._id}>
                    <td><input type="checkbox" checked={selected.includes(order._id)} onChange={() => toggleSelect(order._id)} className="rounded" /></td>
                    <td>
                      <Link to={`/orders/${order._id}`} className="font-mono text-xs font-semibold text-brand-600 hover:underline">{order.orderId}</Link>
                      {order.courier?.trackingId && <div className="text-xs text-gray-400 font-mono">{order.courier.trackingId}</div>}
                    </td>
                    <td>
                      <div className="font-medium text-gray-900 text-xs">{order.customer?.name}</div>
                      <div className="text-xs text-gray-400">{order.customer?.phone}</div>
                    </td>
                    <td>
                      <div className="text-xs text-gray-700 max-w-32 truncate">{order.products?.[0]?.name}</div>
                      {order.products?.length > 1 && <div className="text-xs text-gray-400">+{order.products.length - 1} more</div>}
                      <div className="text-xs text-gray-400">Qty: {order.products?.reduce((s, p) => s + p.quantity, 0)}</div>
                    </td>
                    <td className="font-semibold text-gray-900 text-sm">₹{order.totalAmount?.toLocaleString('en-IN')}</td>
                    <td><StatusBadge status={order.status} /></td>
                    <td><SourceBadge source={order.source} /></td>
                    <td className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleDateString('en-IN')}</td>
                    <td>
                      <div className="flex gap-1 flex-wrap">
                        {order.status === 'new' && (
                          <button onClick={() => handlePack(order._id)} title="Mark Packed"
                            className="text-amber-600 hover:bg-amber-50 px-2 py-1 rounded text-xs font-medium transition-colors">Pack</button>
                        )}
                        {order.status === 'packed' && (
                          <button onClick={() => setShipOrder(order)} title="Mark Shipped"
                            className="text-purple-600 hover:bg-purple-50 px-2 py-1 rounded text-xs font-medium transition-colors">Ship</button>
                        )}
                        {order.status === 'shipped' && (
                          <button onClick={() => handleDeliver(order._id)} title="Mark Delivered"
                            className="text-green-600 hover:bg-green-50 px-2 py-1 rounded text-xs font-medium transition-colors">Deliver</button>
                        )}
                        <button onClick={() => { setEditOrder(order); setShowModal(true); }}
                          className="text-blue-600 hover:bg-blue-50 px-2 py-1 rounded text-xs font-medium transition-colors">Edit</button>
                        <a href={`/api/invoices/${order.orderId}/pdf`} target="_blank" rel="noreferrer"
                          className="text-gray-600 hover:bg-gray-50 px-2 py-1 rounded text-xs font-medium transition-colors">Invoice</a>
                        <button onClick={() => handleDelete(order._id)}
                          className="text-red-400 hover:bg-red-50 px-2 py-1 rounded text-xs font-medium transition-colors">Del</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {orders.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                <div className="text-4xl mb-3">📦</div>
                <p className="font-medium">No orders found</p>
                <p className="text-sm mt-1">Try adjusting your filters or <button onClick={() => setShowModal(true)} className="text-brand-600 underline">add a new order</button></p>
              </div>
            )}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <span className="text-xs text-gray-500">Page {page} of {totalPages} ({total} orders)</span>
            <div className="flex gap-2">
              {page > 1 && <button onClick={() => updateParam('page', page - 1)} className="btn-secondary py-1.5 text-xs">← Prev</button>}
              {page < totalPages && <button onClick={() => updateParam('page', page + 1)} className="btn-secondary py-1.5 text-xs">Next →</button>}
            </div>
          </div>
        )}
      </div>

      {showModal && <OrderModal order={editOrder} onClose={() => setShowModal(false)} onSaved={fetchOrders} />}
      {shipOrder && <ShipModal order={shipOrder} onClose={() => setShipOrder(null)} onSaved={fetchOrders} />}
      {showImport && <CSVImportModal onClose={() => setShowImport(false)} onSaved={fetchOrders} />}
    </div>
  );
}
