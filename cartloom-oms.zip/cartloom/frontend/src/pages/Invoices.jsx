import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Invoices() {
  const [orders, setOrders] = useState([]);
  const [allOrders, setAllOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    Promise.all([api.get('/invoices'), api.get('/orders?limit=200')])
      .then(([inv, all]) => { setOrders(inv.data); setAllOrders(all.data.orders); })
      .catch(() => toast.error('Failed to load invoices'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = orders.filter(o =>
    !search ||
    o.invoiceNumber?.toLowerCase().includes(search.toLowerCase()) ||
    o.orderId?.toLowerCase().includes(search.toLowerCase()) ||
    o.customer?.name?.toLowerCase().includes(search.toLowerCase())
  );

  const totalRevenue = orders.reduce((s, o) => s + (o.totalAmount || 0), 0);

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex flex-wrap items-center gap-4 justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Invoices</h2>
          <p className="text-sm text-gray-500">{orders.length} invoices generated</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cl-card p-4 text-center">
          <div className="text-3xl font-bold text-brand-600">{orders.length}</div>
          <div className="text-xs text-gray-500 mt-1">Invoices Generated</div>
        </div>
        <div className="cl-card p-4 text-center">
          <div className="text-2xl font-bold text-green-600">₹{totalRevenue.toLocaleString('en-IN')}</div>
          <div className="text-xs text-gray-500 mt-1">Total Invoiced</div>
        </div>
        <div className="cl-card p-4 text-center">
          <div className="text-3xl font-bold text-gray-700">{allOrders.length - orders.length}</div>
          <div className="text-xs text-gray-500 mt-1">Pending Invoices</div>
        </div>
      </div>

      {/* Quick generate section */}
      {allOrders.filter(o => !o.invoiceNumber).length > 0 && (
        <div className="cl-card p-5">
          <h3 className="font-semibold text-gray-900 mb-3">Orders Without Invoices</h3>
          <p className="text-sm text-gray-500 mb-3">Click the invoice link below to generate an invoice for any order. It will be auto-numbered and saved.</p>
          <div className="overflow-x-auto">
            <table className="cl-table">
              <thead>
                <tr><th>Order ID</th><th>Customer</th><th>Amount</th><th>Source</th><th>Action</th></tr>
              </thead>
              <tbody>
                {allOrders.filter(o => !o.invoiceNumber).slice(0, 10).map(o => (
                  <tr key={o._id}>
                    <td className="font-mono text-xs text-brand-600 font-semibold">{o.orderId}</td>
                    <td className="text-xs font-medium">{o.customer?.name}</td>
                    <td className="font-semibold text-sm">₹{o.totalAmount?.toLocaleString('en-IN')}</td>
                    <td><span className={`px-2 py-0.5 rounded-full text-xs source-${o.source}`}>{o.source}</span></td>
                    <td>
                      <a href={`/api/invoices/${o.orderId}/pdf`} target="_blank" rel="noreferrer"
                        className="text-brand-600 hover:text-brand-700 text-xs font-medium hover:underline">
                        Generate & Download PDF →
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Invoice history */}
      <div className="cl-card overflow-hidden">
        <div className="cl-card-header">
          <h3 className="font-semibold text-gray-900">Invoice History</h3>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search invoices..."
            className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 w-48" />
        </div>
        {loading ? (
          <div className="flex items-center justify-center h-32"><div className="animate-spin w-7 h-7 border-4 border-brand-600 border-t-transparent rounded-full"></div></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="cl-table">
              <thead>
                <tr><th>Invoice #</th><th>Order ID</th><th>Customer</th><th>Amount</th><th>Date</th><th>Action</th></tr>
              </thead>
              <tbody>
                {filtered.map(o => (
                  <tr key={o._id}>
                    <td className="font-mono text-xs font-semibold text-gray-700">{o.invoiceNumber}</td>
                    <td><Link to={`/orders/${o._id}`} className="font-mono text-xs text-brand-600 hover:underline">{o.orderId}</Link></td>
                    <td className="text-xs font-medium text-gray-800">{o.customer?.name}</td>
                    <td className="font-semibold">₹{o.totalAmount?.toLocaleString('en-IN')}</td>
                    <td className="text-xs text-gray-500">{o.invoiceDate ? new Date(o.invoiceDate).toLocaleDateString('en-IN') : '—'}</td>
                    <td className="flex gap-2">
                      <a href={`/api/invoices/${o.orderId}/pdf`} target="_blank" rel="noreferrer" className="text-brand-600 hover:text-brand-700 text-xs font-medium">📄 PDF</a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-10 text-gray-400">
                <div className="text-4xl mb-3">🧾</div>
                <p>No invoices yet. Generate one from the Orders page.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
