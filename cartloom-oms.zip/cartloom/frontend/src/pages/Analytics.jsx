import React, { useState, useEffect } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, Legend, PieChart, Pie, Cell
} from 'recharts';
import api from '../utils/api';
import toast from 'react-hot-toast';

const CHANNEL_COLORS = { meesho: '#f97316', website: '#3b82f6', manual: '#8b5cf6', instagram: '#ec4899', other: '#6b7280' };

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-3 text-xs">
      <div className="font-semibold text-gray-700 mb-2">{label}</div>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }}></div>
          <span className="text-gray-600">{p.name}:</span>
          <span className="font-semibold">{p.name === 'revenue' ? `₹${(p.value || 0).toLocaleString('en-IN')}` : p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function Analytics() {
  const [summary, setSummary] = useState(null);
  const [revenueData, setRevenueData] = useState([]);
  const [channelStats, setChannelStats] = useState([]);
  const [period, setPeriod] = useState('30');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.get('/analytics/dashboard'),
      api.get(`/analytics/revenue?period=${period}`)
    ]).then(([dash, rev]) => {
      setSummary(dash.data.summary);
      setChannelStats(dash.data.channelStats || []);
      setRevenueData(rev.data || []);
    }).catch(() => toast.error('Failed to load analytics'))
      .finally(() => setLoading(false));
  }, [period]);

  const totalRevenue = revenueData.reduce((s, d) => s + (d.revenue || 0), 0);
  const totalOrders = revenueData.reduce((s, d) => s + (d.orders || 0), 0);
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

  const pieData = channelStats.map(ch => ({
    name: ch._id?.charAt(0).toUpperCase() + ch._id?.slice(1),
    value: ch.count,
    revenue: ch.revenue,
    color: CHANNEL_COLORS[ch._id] || '#6b7280'
  }));

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full"></div></div>;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center gap-4 justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Analytics</h2>
          <p className="text-sm text-gray-500">CartLoom performance overview</p>
        </div>
        <div className="flex gap-2">
          {['7', '30', '90'].map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${period === p ? 'bg-dark-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}>
              {p}d
            </button>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: `Revenue (${period}d)`, value: `₹${totalRevenue.toLocaleString('en-IN')}`, icon: '💰', color: 'text-green-600' },
          { label: `Orders (${period}d)`, value: totalOrders, icon: '📦', color: 'text-blue-600' },
          { label: 'Avg Order Value', value: `₹${Math.round(avgOrderValue).toLocaleString('en-IN')}`, icon: '📊', color: 'text-purple-600' },
          { label: 'Total All-time', value: summary?.totalOrders || 0, icon: '🗃️', color: 'text-brand-600' },
        ].map((kpi, i) => (
          <div key={i} className="cl-card p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl">{kpi.icon}</span>
            </div>
            <div className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</div>
            <div className="text-xs text-gray-500 mt-1">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Revenue chart */}
      <div className="cl-card">
        <div className="cl-card-header">
          <h3 className="font-semibold text-gray-900">Revenue & Orders Over Time</h3>
        </div>
        <div className="p-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="_id" tick={{ fontSize: 10 }} tickFormatter={d => d?.slice(5)} />
              <YAxis yAxisId="left" tick={{ fontSize: 10 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#C8522A" strokeWidth={2.5} dot={false} name="revenue" />
              <Line yAxisId="left" type="monotone" dataKey="orders" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} name="orders" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Channel charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Channel orders bar */}
        <div className="cl-card">
          <div className="cl-card-header"><h3 className="font-semibold text-gray-900">Orders by Channel</h3></div>
          <div className="p-4 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="_id" tick={{ fontSize: 10 }} tickFormatter={d => d?.slice(5)} />
                <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="meesho" fill="#f97316" name="meesho" radius={[3, 3, 0, 0]} />
                <Bar dataKey="website" fill="#3b82f6" name="website" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Channel pie */}
        <div className="cl-card">
          <div className="cl-card-header"><h3 className="font-semibold text-gray-900">Channel Distribution</h3></div>
          <div className="p-4 flex items-center gap-4">
            <div className="flex-shrink-0">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie data={pieData} cx={75} cy={75} innerRadius={45} outerRadius={72} paddingAngle={3} dataKey="value">
                    {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip formatter={(v, n, p) => [`${v} orders (₹${p.payload.revenue?.toLocaleString('en-IN')})`, p.payload.name]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-3">
              {pieData.map((ch, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ background: ch.color }}></div>
                      <span className="font-medium text-gray-800">{ch.name}</span>
                    </div>
                    <span className="text-gray-500 text-xs">{ch.value} orders</span>
                  </div>
                  <div className="bg-gray-100 rounded-full h-1.5">
                    <div className="h-1.5 rounded-full transition-all" style={{ width: `${(ch.value / (totalOrders || 1)) * 100}%`, background: ch.color }}></div>
                  </div>
                  <div className="text-xs text-gray-400 text-right">₹{ch.revenue?.toLocaleString('en-IN')}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Status overview */}
      <div className="cl-card p-5">
        <h3 className="font-semibold text-gray-900 mb-4">Order Status Overview</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { label: 'New', value: summary?.newOrders || 0, color: 'bg-blue-500', light: 'bg-blue-50 text-blue-700' },
            { label: 'Packed', value: summary?.packedOrders || 0, color: 'bg-amber-500', light: 'bg-amber-50 text-amber-700' },
            { label: 'Shipped', value: summary?.shippedOrders || 0, color: 'bg-purple-500', light: 'bg-purple-50 text-purple-700' },
            { label: 'Delivered', value: summary?.deliveredOrders || 0, color: 'bg-green-500', light: 'bg-green-50 text-green-700' },
            { label: 'Today', value: summary?.todayOrders || 0, color: 'bg-brand-500', light: 'bg-brand-50 text-brand-700' },
          ].map((s, i) => (
            <div key={i} className={`rounded-xl p-4 text-center ${s.light}`}>
              <div className="text-3xl font-bold">{s.value}</div>
              <div className="text-xs font-semibold mt-1 uppercase tracking-wide">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
