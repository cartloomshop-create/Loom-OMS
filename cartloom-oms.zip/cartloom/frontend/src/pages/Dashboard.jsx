import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import api from '../utils/api';
import toast from 'react-hot-toast';

const StatCard = ({ label, value, sub, color, icon }) => (
  <div className="cl-card p-5 flex items-start gap-4">
    <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${color}`}>{icon}</div>
    <div className="min-w-0">
      <div className="text-2xl font-bold text-gray-900 leading-tight">{value}</div>
      <div className="text-sm font-medium text-gray-600">{label}</div>
      {sub && <div className="text-xs text-gray-400 mt-0.5">{sub}</div>}
    </div>
  </div>
);

const STATUS_COLORS = { new: '#3b82f6', packed: '#f59e0b', shipped: '#8b5cf6', delivered: '#10b981', cancelled: '#ef4444' };

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/analytics/dashboard').then(r => setData(r.data)).catch(() => toast.error('Failed to load dashboard')).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full"></div>
    </div>
  );

  const { summary, channelStats, last7Days, recentOrders } = data || {};

  const statusPieData = [
    { name: 'New', value: summary?.newOrders || 0, color: STATUS_COLORS.new },
    { name: 'Packed', value: summary?.packedOrders || 0, color: STATUS_COLORS.packed },
    { name: 'Shipped', value: summary?.shippedOrders || 0, color: STATUS_COLORS.shipped },
    { name: 'Delivered', value: summary?.deliveredOrders || 0, color: STATUS_COLORS.delivered },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-dark-800 to-dark-700 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="font-display text-2xl font-semibold">Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'} 👋</h2>
            <p className="text-gray-300 text-sm mt-1">Here's what's happening with CartLoom today</p>
          </div>
          <div className="flex gap-3">
            <Link to="/orders?status=new" className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
              View New Orders ({summary?.newOrders || 0})
            </Link>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Today's Orders" value={summary?.todayOrders || 0} sub="Created today" color="bg-blue-50" icon="📬" />
        <StatCard label="To Pack" value={summary?.newOrders || 0} sub="Awaiting packing" color="bg-amber-50" icon="📦" />
        <StatCard label="Shipped" value={summary?.shippedOrders || 0} sub="In transit" color="bg-purple-50" icon="🚚" />
        <StatCard label="Revenue (30d)" value={`₹${((summary?.revenue30Days || 0)).toLocaleString('en-IN')}`} sub={`${summary?.orders30Days || 0} orders`} color="bg-green-50" icon="💰" />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Line chart */}
        <div className="lg:col-span-2 cl-card">
          <div className="cl-card-header">
            <h3 className="font-semibold text-gray-900">Orders (Last 7 Days)</h3>
            <Link to="/analytics" className="text-brand-600 text-sm font-medium hover:underline">View all →</Link>
          </div>
          <div className="p-4 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={last7Days || []}>
                <XAxis dataKey="_id" tick={{ fontSize: 11 }} tickFormatter={d => d?.slice(5)} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip formatter={(v, n) => [n === 'revenue' ? `₹${v.toLocaleString('en-IN')}` : v, n === 'revenue' ? 'Revenue' : 'Orders']} labelFormatter={l => `Date: ${l}`} />
                <Line type="monotone" dataKey="orders" stroke="#C8522A" strokeWidth={2.5} dot={{ fill: '#C8522A', r: 4 }} />
                <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} dot={false} strokeDasharray="4 2" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie chart */}
        <div className="cl-card">
          <div className="cl-card-header">
            <h3 className="font-semibold text-gray-900">Order Status</h3>
          </div>
          <div className="p-4 flex flex-col items-center">
            <div className="h-36">
              <ResponsiveContainer width={160} height={144}>
                <PieChart>
                  <Pie data={statusPieData} cx={75} cy={68} innerRadius={40} outerRadius={65} paddingAngle={3} dataKey="value">
                    {statusPieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-full mt-2 space-y-1.5">
              {statusPieData.map(s => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: s.color }}></div>
                    <span className="text-gray-600">{s.name}</span>
                  </div>
                  <span className="font-semibold text-gray-800">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Channel stats + Recent orders */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Channel bar chart */}
        <div className="cl-card">
          <div className="cl-card-header">
            <h3 className="font-semibold text-gray-900">Channel Performance</h3>
          </div>
          <div className="p-4 space-y-3">
            {(channelStats || []).map(ch => (
              <div key={ch._id} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium source-${ch._id}`}>{ch._id?.charAt(0).toUpperCase() + ch._id?.slice(1)}</span>
                  <span className="text-gray-500 text-xs">{ch.count} orders</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 rounded-full h-2">
                    <div className="h-2 rounded-full bg-brand-600 transition-all"
                      style={{ width: `${Math.min(100, (ch.count / (summary?.totalOrders || 1)) * 100)}%` }}></div>
                  </div>
                  <span className="text-xs font-semibold text-gray-700">₹{ch.revenue?.toLocaleString('en-IN')}</span>
                </div>
              </div>
            ))}
            {(!channelStats || channelStats.length === 0) && <p className="text-sm text-gray-400 text-center py-4">No data yet</p>}
          </div>
        </div>

        {/* Recent orders */}
        <div className="lg:col-span-2 cl-card overflow-hidden">
          <div className="cl-card-header">
            <h3 className="font-semibold text-gray-900">Recent Orders</h3>
            <Link to="/orders" className="text-brand-600 text-sm font-medium hover:underline">View all →</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="cl-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                {(recentOrders || []).map(order => (
                  <tr key={order._id}>
                    <td>
                      <Link to={`/orders/${order._id}`} className="font-mono text-xs font-medium text-brand-600 hover:underline">{order.orderId}</Link>
                    </td>
                    <td className="font-medium text-gray-800 text-xs">{order.customer?.name}</td>
                    <td className="font-semibold text-gray-900 text-xs">₹{order.totalAmount?.toLocaleString('en-IN')}</td>
                    <td><span className={`px-2 py-0.5 rounded-full text-xs font-medium status-${order.status}`}>{order.status}</span></td>
                    <td><span className={`px-2 py-0.5 rounded-full text-xs font-medium source-${order.source}`}>{order.source}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(!recentOrders || recentOrders.length === 0) && (
              <div className="text-center py-8 text-gray-400 text-sm">No orders yet. <Link to="/orders" className="text-brand-600 underline">Add one!</Link></div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
