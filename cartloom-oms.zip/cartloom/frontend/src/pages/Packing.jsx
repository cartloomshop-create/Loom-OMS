import React, { useState, useEffect } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Packing() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState([]);
  const [generating, setGenerating] = useState(false);

  const fetchQueue = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/packing/queue');
      setOrders(data);
    } catch { toast.error('Failed to load packing queue'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchQueue(); }, []);

  const handlePack = async (id) => {
    try {
      await api.patch(`/orders/${id}/pack`);
      toast.success('Marked as packed!');
      fetchQueue();
      setSelected(s => s.filter(x => x !== id));
    } catch { toast.error('Failed to update'); }
  };

  const handleBulkPack = async () => {
    if (!selected.length) return toast.error('Select at least one order');
    try {
      await api.post('/orders/bulk/status', { orderIds: selected, status: 'packed' });
      toast.success(`${selected.length} orders marked as packed!`);
      setSelected([]);
      fetchQueue();
    } catch { toast.error('Bulk update failed'); }
  };

  const handlePrintSlip = async () => {
    if (!selected.length) return toast.error('Select orders first');
    setGenerating(true);
    try {
      const token = localStorage.getItem('cl_token');
      const res = await fetch('/api/packing/slip/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ orderIds: selected })
      });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      toast.success('Packing slip generated!');
    } catch { toast.error('Failed to generate slip'); }
    finally { setGenerating(false); }
  };

  const toggleSelect = (id) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const toggleAll = () => setSelected(selected.length === orders.length ? [] : orders.map(o => o._id));

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-4 justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Packing Queue</h2>
          <p className="text-sm text-gray-500">{orders.length} orders awaiting packing</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={handlePrintSlip} disabled={!selected.length || generating} className="btn-secondary disabled:opacity-50">
            🖨️ {generating ? 'Generating...' : `Print Slip (${selected.length})`}
          </button>
          <button onClick={handleBulkPack} disabled={!selected.length} className="btn-primary disabled:opacity-50">
            📦 Mark Packed ({selected.length})
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cl-card p-4 text-center">
          <div className="text-3xl font-bold text-blue-600">{orders.length}</div>
          <div className="text-xs text-gray-500 mt-1">Pending Packing</div>
        </div>
        <div className="cl-card p-4 text-center">
          <div className="text-3xl font-bold text-amber-600">{selected.length}</div>
          <div className="text-xs text-gray-500 mt-1">Selected</div>
        </div>
        <div className="cl-card p-4 text-center">
          <div className="text-3xl font-bold text-green-600">
            ₹{orders.filter(o => selected.includes(o._id)).reduce((s, o) => s + o.totalAmount, 0).toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-gray-500 mt-1">Selected Value</div>
        </div>
      </div>

      {/* Table */}
      <div className="cl-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin w-7 h-7 border-4 border-brand-600 border-t-transparent rounded-full"></div>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-5xl mb-4">🎉</div>
            <p className="font-semibold text-gray-600 text-lg">All packed up!</p>
            <p className="text-sm mt-1">No orders waiting to be packed.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="cl-table">
              <thead>
                <tr>
                  <th className="w-10">
                    <input type="checkbox" checked={selected.length === orders.length && orders.length > 0} onChange={toggleAll} className="rounded" />
                  </th>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Address</th>
                  <th>Products</th>
                  <th>Amount</th>
                  <th>Source</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order._id} className={selected.includes(order._id) ? 'bg-brand-50/50' : ''}>
                    <td>
                      <input type="checkbox" checked={selected.includes(order._id)} onChange={() => toggleSelect(order._id)} className="rounded" />
                    </td>
                    <td className="font-mono text-xs font-semibold text-brand-600">{order.orderId}</td>
                    <td>
                      <div className="font-medium text-xs text-gray-900">{order.customer?.name}</div>
                      <div className="text-xs text-gray-400">{order.customer?.phone}</div>
                    </td>
                    <td className="text-xs text-gray-600 max-w-36">
                      <div>{order.customer?.address?.line1}</div>
                      <div className="text-gray-400">{[order.customer?.address?.city, order.customer?.address?.pincode].filter(Boolean).join(', ')}</div>
                    </td>
                    <td className="text-xs">
                      {order.products?.map((p, i) => (
                        <div key={i} className="flex items-center gap-1">
                          <span className="w-4 h-4 rounded bg-brand-100 text-brand-700 text-xs flex items-center justify-center font-bold">{p.quantity}</span>
                          <span className="text-gray-700 truncate max-w-28">{p.name}</span>
                        </div>
                      ))}
                    </td>
                    <td className="font-semibold text-sm">₹{order.totalAmount?.toLocaleString('en-IN')}</td>
                    <td><span className={`px-2 py-0.5 rounded-full text-xs font-medium source-${order.source}`}>{order.source}</span></td>
                    <td className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString('en-IN')}</td>
                    <td>
                      <button onClick={() => handlePack(order._id)} className="btn-primary py-1.5 text-xs">Pack ✓</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Packing tips */}
      <div className="cl-card p-5">
        <h3 className="font-semibold text-gray-900 mb-3 text-sm">📋 Packing Checklist</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {['Verify order details', 'Include earring backs', 'Pack in box/pouch', 'Attach order slip', 'Seal properly', 'Add thank you card', 'Check address label', 'Ready for pickup'].map((item, i) => (
            <label key={i} className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
              <input type="checkbox" className="rounded text-brand-600" />
              {item}
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}
