import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';
import ShipModal from '../components/orders/ShipModal';

const StatusBadge = ({ status }) => (
  <span className={`px-3 py-1 rounded-full text-sm font-semibold status-${status}`}>{status?.charAt(0).toUpperCase() + status?.slice(1)}</span>
);

const STEPS = ['new', 'packed', 'shipped', 'delivered'];

export default function OrderDetail() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [shipModal, setShipModal] = useState(false);

  const fetchOrder = async () => {
    try {
      const { data } = await api.get(`/orders/${id}`);
      setOrder(data);
    } catch { toast.error('Order not found'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchOrder(); }, [id]);

  const handlePack = async () => {
    await api.patch(`/orders/${order._id}/pack`);
    toast.success('Marked as packed'); fetchOrder();
  };
  const handleDeliver = async () => {
    await api.patch(`/orders/${order._id}/deliver`);
    toast.success('Marked as delivered'); fetchOrder();
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full"></div></div>;
  if (!order) return <div className="text-center py-12 text-gray-400">Order not found</div>;

  const stepIdx = STEPS.indexOf(order.status);

  return (
    <div className="space-y-5 animate-fade-in max-w-4xl">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-4 justify-between">
        <div className="flex items-center gap-3">
          <Link to="/orders" className="text-gray-400 hover:text-gray-600 text-sm">← Orders</Link>
          <span className="text-gray-300">/</span>
          <span className="font-mono font-semibold text-brand-600">{order.orderId}</span>
          <StatusBadge status={order.status} />
        </div>
        <div className="flex gap-2 flex-wrap">
          {order.status === 'new' && <button onClick={handlePack} className="btn-primary">📦 Mark Packed</button>}
          {order.status === 'packed' && <button onClick={() => setShipModal(true)} className="btn-primary">🚚 Mark Shipped</button>}
          {order.status === 'shipped' && <button onClick={handleDeliver} className="btn-success">✅ Mark Delivered</button>}
          <a href={`/api/invoices/${order.orderId}/pdf`} target="_blank" rel="noreferrer" className="btn-secondary">🧾 Invoice PDF</a>
        </div>
      </div>

      {/* Progress tracker */}
      <div className="cl-card p-5">
        <div className="flex items-center gap-0">
          {STEPS.map((step, i) => (
            <React.Fragment key={step}>
              <div className={`flex flex-col items-center flex-1 ${i <= stepIdx ? 'opacity-100' : 'opacity-30'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 ${i < stepIdx ? 'bg-green-500 border-green-500 text-white' : i === stepIdx ? 'bg-brand-600 border-brand-600 text-white' : 'bg-white border-gray-300 text-gray-400'}`}>
                  {i < stepIdx ? '✓' : i + 1}
                </div>
                <span className={`text-xs mt-1 font-medium capitalize ${i === stepIdx ? 'text-brand-600' : 'text-gray-400'}`}>{step}</span>
              </div>
              {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 -mt-4 ${i < stepIdx ? 'bg-green-400' : 'bg-gray-200'}`}></div>}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Customer details */}
        <div className="cl-card p-5">
          <h3 className="font-semibold text-gray-900 mb-3 text-sm uppercase tracking-wider text-gray-500">Customer</h3>
          <div className="space-y-2">
            <div className="font-bold text-gray-900 text-lg">{order.customer.name}</div>
            {order.customer.phone && <div className="flex items-center gap-2 text-sm text-gray-600">📞 {order.customer.phone}</div>}
            {order.customer.email && <div className="flex items-center gap-2 text-sm text-gray-600">✉️ {order.customer.email}</div>}
            {order.customer.address?.line1 && (
              <div className="text-sm text-gray-600 bg-gray-50 rounded-lg p-3 mt-3">
                <div className="font-medium text-gray-700 mb-1">📍 Delivery Address</div>
                <div>{order.customer.address.line1}</div>
                {order.customer.address.line2 && <div>{order.customer.address.line2}</div>}
                <div>{[order.customer.address.city, order.customer.address.state, order.customer.address.pincode].filter(Boolean).join(', ')}</div>
              </div>
            )}
            {/* WhatsApp mock */}
            {order.customer.phone && (
              <a href={`https://wa.me/91${order.customer.phone}?text=Hi ${order.customer.name}! Your CartLoom order ${order.orderId} has been ${order.status}. Thank you for shopping with us! 🎉`}
                target="_blank" rel="noreferrer"
                className="flex items-center gap-2 text-sm text-green-600 font-medium hover:text-green-700 mt-2">
                <span className="text-base">💬</span> WhatsApp Customer
              </a>
            )}
          </div>
        </div>

        {/* Products */}
        <div className="cl-card p-5">
          <h3 className="font-semibold mb-3 text-sm uppercase tracking-wider text-gray-500">Products</h3>
          <div className="space-y-3">
            {order.products.map((p, i) => (
              <div key={i} className="flex items-start justify-between gap-2 pb-3 border-b border-gray-100 last:border-0">
                <div>
                  <div className="font-medium text-gray-900 text-sm">{p.name}</div>
                  {p.sku && <div className="text-xs text-gray-400 font-mono">SKU: {p.sku}</div>}
                  <div className="text-xs text-gray-500">HSN: {p.hsn || '7117'} | GST: {p.gstRate || 3}%</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="font-semibold text-gray-900">₹{p.price}</div>
                  <div className="text-xs text-gray-500">Qty: {p.quantity}</div>
                  <div className="text-xs text-brand-600 font-semibold">₹{(p.price * p.quantity).toLocaleString('en-IN')}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-200 space-y-1">
            {order.shippingCharge > 0 && <div className="flex justify-between text-sm text-gray-600"><span>Shipping</span><span>₹{order.shippingCharge}</span></div>}
            {order.discountAmount > 0 && <div className="flex justify-between text-sm text-green-600"><span>Discount</span><span>-₹{order.discountAmount}</span></div>}
            <div className="flex justify-between font-bold text-gray-900"><span>Total</span><span>₹{order.totalAmount?.toLocaleString('en-IN')}</span></div>
          </div>
        </div>

        {/* QR + Shipment */}
        <div className="space-y-4">
          {order.qrCode && (
            <div className="cl-card p-5 text-center">
              <h3 className="font-semibold mb-3 text-sm uppercase tracking-wider text-gray-500">Order QR Code</h3>
              <img src={order.qrCode} alt="QR Code" className="w-32 h-32 mx-auto rounded-lg" />
              <p className="text-xs text-gray-400 mt-2">{order.orderId}</p>
            </div>
          )}
          <div className="cl-card p-5">
            <h3 className="font-semibold mb-3 text-sm uppercase tracking-wider text-gray-500">Shipment</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Source</span><span className={`px-2 py-0.5 rounded-full text-xs font-medium source-${order.source}`}>{order.source}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Invoice #</span><span className="font-mono text-xs">{order.invoiceNumber || '—'}</span></div>
              {order.courier?.name && <div className="flex justify-between"><span className="text-gray-500">Courier</span><span>{order.courier.name}</span></div>}
              {order.courier?.trackingId && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Tracking</span>
                  <span className="font-mono text-xs text-brand-600">{order.courier.trackingId}</span>
                </div>
              )}
              {order.courier?.shippedAt && <div className="flex justify-between"><span className="text-gray-500">Shipped</span><span className="text-xs">{new Date(order.courier.shippedAt).toLocaleDateString('en-IN')}</span></div>}
              {order.notes && <div className="bg-yellow-50 border border-yellow-200 rounded p-2 text-xs text-yellow-800 mt-2">📝 {order.notes}</div>}
            </div>
          </div>
        </div>
      </div>

      {shipModal && <ShipModal order={order} onClose={() => setShipModal(false)} onSaved={fetchOrder} />}
    </div>
  );
}
