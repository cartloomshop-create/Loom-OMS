import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const navItems = [
  { path: '/', icon: '⬛', label: 'Dashboard', emoji: '📊' },
  { path: '/orders', icon: '⬛', label: 'Orders', emoji: '📦' },
  { path: '/packing', icon: '⬛', label: 'Packing', emoji: '🎁' },
  { path: '/invoices', icon: '⬛', label: 'Invoices', emoji: '🧾' },
  { path: '/analytics', icon: '⬛', label: 'Analytics', emoji: '📈' },
];

export default function Layout({ children }) {
  const { pathname } = useLocation();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-30 w-60 flex flex-col bg-dark-800 transition-transform duration-300 lg:relative lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
          <div className="w-9 h-9 rounded-lg bg-brand-600 flex items-center justify-center text-white font-bold text-lg">C</div>
          <div>
            <div className="font-display text-white font-semibold text-lg leading-tight">CartLoom</div>
            <div className="text-xs text-gray-400">Order Management</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const active = pathname === item.path || (item.path !== '/' && pathname.startsWith(item.path));
            return (
              <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${active ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-400 hover:bg-white/10 hover:text-white'}`}>
                <span className="text-base">{item.emoji}</span>
                {item.label}
                {item.label === 'Orders' && active && (
                  <span className="ml-auto bg-white/20 text-white text-xs px-2 py-0.5 rounded-full">Live</span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="px-3 py-4 border-t border-white/10">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-white/5">
            <div className="w-8 h-8 rounded-full bg-brand-600 flex items-center justify-center text-white font-semibold text-sm">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">{user?.name}</div>
              <div className="text-xs text-gray-400 truncate">{user?.role}</div>
            </div>
            <button onClick={handleLogout} title="Logout"
              className="text-gray-400 hover:text-red-400 transition-colors text-lg">⏻</button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-4 lg:px-6">
          <button className="lg:hidden text-gray-600 text-xl" onClick={() => setSidebarOpen(true)}>☰</button>
          <div className="flex-1">
            <h1 className="font-semibold text-gray-900 text-sm">
              {navItems.find(n => pathname === n.path || (n.path !== '/' && pathname.startsWith(n.path)))?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:block text-xs text-gray-500 bg-green-50 text-green-600 border border-green-200 px-2.5 py-1 rounded-full font-medium">
              ● Live
            </span>
            <span className="text-xs text-gray-500">{new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
