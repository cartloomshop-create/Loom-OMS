import React, { useState } from 'react';
import api from '../../utils/api';
import toast from 'react-hot-toast';

const COURIERS = ['Delhivery', 'DTDC', 'BlueDart', 'Xpressbees', 'Ecom Express', 'India Post', 'Shiprocket', 'Other'];

export default function ShipModal({ order, onClose, onSaved }) {
  const [courierName, setCourierName] = useState('Delhivery');
  const [trackingId, setTrackingId] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.patch(`/orders/${order._id}/ship`, { courierName, trackingId });
      toast.success('Order marked as shipped!');
      onSaved(); onClose();
    } catch { toast.error('Failed to update'); }
    finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm animate-fade-in">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-bold text-gray-900">Ship Order</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl">×</button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-gray-50 rounded-lg p-3 text-sm">
            <span className="font-mono text-brand-600 font-semibold">{order.orderId}</span>
            <span className="text-gray-500 ml-2">— {order.customer?.name}</span>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Courier Partner</label>
            <select value={courierName} onChange={e => setCourierName(e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
              {COURIERS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Tracking ID</label>
            <input required value={trackingId} onChange={e => setTrackingId(e.target.value)} placeholder="Enter tracking number"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-brand-400" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">
              {loading ? 'Saving...' : '🚚 Mark Shipped'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
