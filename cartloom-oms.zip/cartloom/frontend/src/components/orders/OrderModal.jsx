import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import toast from 'react-hot-toast';

const defaultProduct = { name: '', quantity: 1, price: 0, sku: '', hsn: '7117', gstRate: 3 };

export default function OrderModal({ order, onClose, onSaved }) {
  const isEdit = !!order;
  const [form, setForm] = useState({
    customer: { name: '', phone: '', email: '', address: { line1: '', city: '', state: '', pincode: '' } },
    products: [{ ...defaultProduct }],
    totalAmount: 0,
    source: 'manual',
    shippingCharge: 0,
    discountAmount: 0,
    notes: '',
    status: 'new',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (order) {
      setForm({
        customer: { name: order.customer?.name || '', phone: order.customer?.phone || '', email: order.customer?.email || '', address: { line1: order.customer?.address?.line1 || '', city: order.customer?.address?.city || '', state: order.customer?.address?.state || '', pincode: order.customer?.address?.pincode || '' } },
        products: order.products?.length ? order.products : [{ ...defaultProduct }],
        totalAmount: order.totalAmount || 0,
        source: order.source || 'manual',
        shippingCharge: order.shippingCharge || 0,
        discountAmount: order.discountAmount || 0,
        notes: order.notes || '',
        status: order.status || 'new',
      });
    }
  }, [order]);

  const calcTotal = (products, shipping, discount) => {
    const sub = products.reduce((s, p) => s + (parseFloat(p.price) || 0) * (parseInt(p.quantity) || 0), 0);
    return Math.max(0, sub + parseFloat(shipping || 0) - parseFloat(discount || 0));
  };

  const setCustomer = (field, val) => setForm(f => ({ ...f, customer: { ...f.customer, [field]: val } }));
  const setAddress = (field, val) => setForm(f => ({ ...f, customer: { ...f.customer, address: { ...f.customer.address, [field]: val } } }));
  const setProduct = (i, field, val) => {
    const products = [...form.products];
    products[i] = { ...products[i], [field]: field === 'quantity' || field === 'price' ? parseFloat(val) || 0 : val };
    const total = calcTotal(products, form.shippingCharge, form.discountAmount);
    setForm(f => ({ ...f, products, totalAmount: total }));
  };
  const addProduct = () => setForm(f => ({ ...f, products: [...f.products, { ...defaultProduct }] }));
  const removeProduct = (i) => {
    const products = form.products.filter((_, idx) => idx !== i);
    setForm(f => ({ ...f, products, totalAmount: calcTotal(products, f.shippingCharge, f.discountAmount) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isEdit) await api.put(`/orders/${order._id}`, form);
      else await api.post('/orders', form);
      toast.success(isEdit ? 'Order updated!' : 'Order created!');
      onSaved(); onClose();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save'); }
    finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="font-bold text-gray-900 text-lg">{isEdit ? 'Edit Order' : 'New Order'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">×</button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Source + Status */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">Channel</label>
              <select value={form.source} onChange={e => setForm(f => ({ ...f, source: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
                {['manual', 'meesho', 'website', 'instagram', 'other'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">Status</label>
              <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
                {['new', 'packed', 'shipped', 'delivered', 'cancelled'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
              </select>
            </div>
          </div>

          {/* Customer */}
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Customer Details</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <input required value={form.customer.name} onChange={e => setCustomer('name', e.target.value)}
                  placeholder="Full Name *" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              </div>
              <input value={form.customer.phone} onChange={e => setCustomer('phone', e.target.value)} placeholder="Phone" className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              <input value={form.customer.email} onChange={e => setCustomer('email', e.target.value)} placeholder="Email" type="email" className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              <div className="col-span-2">
                <input value={form.customer.address.line1} onChange={e => setAddress('line1', e.target.value)} placeholder="Address Line 1" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              </div>
              <input value={form.customer.address.city} onChange={e => setAddress('city', e.target.value)} placeholder="City" className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              <input value={form.customer.address.state} onChange={e => setAddress('state', e.target.value)} placeholder="State" className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
              <input value={form.customer.address.pincode} onChange={e => setAddress('pincode', e.target.value)} placeholder="Pincode" className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
            </div>
          </div>

          {/* Products */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Products</h3>
              <button type="button" onClick={addProduct} className="text-brand-600 text-xs font-medium hover:underline">+ Add Product</button>
            </div>
            <div className="space-y-3">
              {form.products.map((p, i) => (
                <div key={i} className="bg-gray-50 rounded-lg p-3 space-y-2">
                  <div className="flex gap-2">
                    <input required value={p.name} onChange={e => setProduct(i, 'name', e.target.value)} placeholder="Product name *"
                      className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-400" />
                    {form.products.length > 1 && (
                      <button type="button" onClick={() => removeProduct(i)} className="text-red-400 hover:text-red-600 px-2 text-lg">×</button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <input type="number" value={p.price} onChange={e => setProduct(i, 'price', e.target.value)} placeholder="Price ₹" min="0"
                      className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-400" />
                    <input type="number" value={p.quantity} onChange={e => setProduct(i, 'quantity', e.target.value)} placeholder="Qty" min="1"
                      className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-400" />
                    <input value={p.sku} onChange={e => setProduct(i, 'sku', e.target.value)} placeholder="SKU"
                      className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-400" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Charges */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-gray-500 mb-1">Shipping ₹</label>
              <input type="number" value={form.shippingCharge} onChange={e => { const v = parseFloat(e.target.value) || 0; setForm(f => ({ ...f, shippingCharge: v, totalAmount: calcTotal(f.products, v, f.discountAmount) })); }} min="0"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Discount ₹</label>
              <input type="number" value={form.discountAmount} onChange={e => { const v = parseFloat(e.target.value) || 0; setForm(f => ({ ...f, discountAmount: v, totalAmount: calcTotal(f.products, f.shippingCharge, v) })); }} min="0"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Total ₹</label>
              <input type="number" value={form.totalAmount} onChange={e => setForm(f => ({ ...f, totalAmount: parseFloat(e.target.value) || 0 }))} min="0"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-semibold bg-brand-50 focus:outline-none focus:ring-2 focus:ring-brand-400" />
            </div>
          </div>

          {/* Notes */}
          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Notes (optional)" rows={2}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 resize-none" />

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">
              {loading ? 'Saving...' : isEdit ? 'Update Order' : 'Create Order'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
