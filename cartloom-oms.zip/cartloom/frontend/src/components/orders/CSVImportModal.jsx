import React, { useState } from 'react';
import api from '../../utils/api';
import toast from 'react-hot-toast';

export default function CSVImportModal({ onClose, onSaved }) {
  const [file, setFile] = useState(null);
  const [source, setSource] = useState('meesho');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleImport = async (e) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('source', source);
      const { data } = await api.post('/orders/import/csv', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setResult(data);
      toast.success(`Imported ${data.imported} orders!`);
      onSaved();
    } catch (err) { toast.error(err.response?.data?.message || 'Import failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-fade-in">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-bold text-gray-900">Import Orders via CSV</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl">×</button>
        </div>
        <div className="p-6 space-y-4">
          {result ? (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-3xl mx-auto">✅</div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{result.imported}</div>
                <div className="text-gray-500 text-sm">orders imported successfully</div>
                <div className="text-xs text-gray-400 mt-1">{result.total - result.imported} rows skipped</div>
              </div>
              <button onClick={onClose} className="btn-primary w-full justify-center">Done</button>
            </div>
          ) : (
            <form onSubmit={handleImport} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Source Channel</label>
                <select value={source} onChange={e => setSource(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white">
                  <option value="meesho">Meesho</option>
                  <option value="website">Website</option>
                  <option value="instagram">Instagram</option>
                  <option value="manual">Manual</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">CSV File</label>
                <div className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${file ? 'border-brand-400 bg-brand-50' : 'border-gray-200 hover:border-brand-300'}`}
                  onClick={() => document.getElementById('csv-input').click()}>
                  <input id="csv-input" type="file" accept=".csv" onChange={e => setFile(e.target.files[0])} className="hidden" />
                  {file ? (
                    <div>
                      <div className="text-3xl mb-2">📄</div>
                      <div className="font-medium text-gray-900 text-sm">{file.name}</div>
                      <div className="text-xs text-gray-400 mt-1">{(file.size / 1024).toFixed(1)} KB</div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-3xl mb-2">📥</div>
                      <div className="font-medium text-gray-600 text-sm">Click to upload CSV</div>
                      <div className="text-xs text-gray-400 mt-1">Meesho export format supported</div>
                    </div>
                  )}
                </div>
              </div>

              {/* Column guide */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="text-xs font-semibold text-blue-700 mb-1.5">Expected CSV Columns:</div>
                <div className="font-mono text-xs text-blue-600 leading-relaxed">
                  Customer Name, Phone, Address, City, State, Pincode, Product, Quantity, Price, Order ID
                </div>
              </div>

              <div className="flex gap-3">
                <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={!file || loading} className="btn-primary flex-1 justify-center disabled:opacity-60">
                  {loading ? 'Importing...' : '📥 Import Orders'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
